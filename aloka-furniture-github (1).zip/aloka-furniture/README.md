# Aloka Furniture Website

A responsive Melamine furniture website built with HTML5, CSS3 and Vanilla JavaScript.

## Files
- `index.html` - website structure and content
- `style.css` - responsive design and styling
- `script.js` - navigation, filters, modals, gallery, validation and animations
- `images/logo.png` - supplied Aloka logo image
- `images/cupboard-1.jpeg` - supplied cupboard/product image

## GitHub Pages
1. Create a new GitHub repository.
2. Upload all files and the `images` folder.
3. Make sure `index.html` is in the repository root.
4. Go to **Settings → Pages**.
5. Select **Deploy from a branch**, choose `main`, folder `/ (root)`, then Save.
6. GitHub will provide your website URL.

## Before publishing
Replace `Location: Your showroom / location` with the real address/location. Add more product images to `images/` and update the product/gallery image paths in `index.html`.

The supplied phone numbers from the provided product artwork are already used for the WhatsApp/call buttons:
- +94 78 367 9930
- +94 78 355 4433
