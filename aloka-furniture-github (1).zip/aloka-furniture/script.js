const menuToggle=document.getElementById('menuToggle');
const navMenu=document.getElementById('navMenu');
menuToggle.addEventListener('click',()=>navMenu.classList.toggle('open'));
navMenu.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>navMenu.classList.remove('open')));

const filterButtons=document.querySelectorAll('.cat');
const cards=document.querySelectorAll('.product-card');
filterButtons.forEach(btn=>btn.addEventListener('click',()=>{
  filterButtons.forEach(b=>b.classList.remove('active')); btn.classList.add('active');
  const filter=btn.dataset.filter;
  cards.forEach(card=>{const cats=card.dataset.category.split(' '); card.classList.toggle('hidden',filter!=='all'&&!cats.includes(filter));});
}));

const productModal=document.getElementById('productModal');
const modalImage=document.getElementById('modalImage');
const modalTitle=document.getElementById('modalTitle');
const modalPrice=document.getElementById('modalPrice');
const modalWarranty=document.getElementById('modalWarranty');
const modalCategory=document.getElementById('modalCategory');
const modalDescription=document.getElementById('modalDescription');
const modalWhatsapp=document.getElementById('modalWhatsapp');
cards.forEach(card=>card.querySelector('.details-btn').addEventListener('click',()=>{
  const name=card.dataset.name, price=card.dataset.price, image=card.dataset.image;
  modalImage.src=image; modalTitle.textContent=name; modalPrice.textContent=price;
  modalCategory.textContent=card.querySelector('.category-label').textContent;
  modalDescription.textContent=card.querySelector('p').textContent;
  modalWarranty.textContent=card.dataset.warranty||'Warranty details available on request.';
  modalWhatsapp.href='https://wa.me/94783679930?text='+encodeURIComponent(`Hello Aloka Furniture, I am interested in ${name}. Please send me more details.`);
  productModal.classList.add('show'); productModal.setAttribute('aria-hidden','false');
}));

const lightbox=document.getElementById('lightbox'), lightboxImage=document.getElementById('lightboxImage');
document.querySelectorAll('.gallery-item').forEach(item=>item.addEventListener('click',()=>{lightboxImage.src=item.dataset.image;lightbox.classList.add('show');}));
document.querySelectorAll('[data-close]').forEach(btn=>btn.addEventListener('click',()=>{document.getElementById(btn.dataset.close).classList.remove('show')}));
[productModal,lightbox].forEach(modal=>modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.remove('show')}));
document.addEventListener('keydown',e=>{if(e.key==='Escape'){productModal.classList.remove('show');lightbox.classList.remove('show')}});

const form=document.getElementById('contactForm'), msg=document.getElementById('formMessage');
form.addEventListener('submit',e=>{e.preventDefault();if(!form.checkValidity()){form.reportValidity();return;}msg.textContent='Thank you! Your inquiry has been received. We will contact you soon.';msg.style.color='#16803a';form.reset();});

const topBtn=document.getElementById('topBtn');
window.addEventListener('scroll',()=>topBtn.classList.toggle('show',window.scrollY>500));
topBtn.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));

const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting)entry.target.classList.add('visible')}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));
